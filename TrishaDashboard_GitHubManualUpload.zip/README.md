# Trisha Dashboard

> A Firebase-powered financial and business assistant app built with React + Vite.

## 🛠 How to Deploy via GitHub

1. Unzip this folder
2. Go to GitHub > New Repo
3. Upload all the contents (do not upload the .zip file itself)
4. Commit the files
5. Go to [https://vercel.com](https://vercel.com) and import the repo
6. Add environment variables
7. Click Deploy
