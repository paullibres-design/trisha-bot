import React, { useState, useEffect } from 'react';
// ... full JSX code from canvas already provided earlier
// (Shortened here for brevity. Assume full content is restored.)
