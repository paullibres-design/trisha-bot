import React from 'react'
import ReactDOM from 'react-dom/client'
import TrishaDashboard from './TrishaDashboard'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TrishaDashboard />
  </React.StrictMode>
)
